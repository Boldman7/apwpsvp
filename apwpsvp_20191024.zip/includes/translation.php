<table class="form-table">
    <tr valign="top">
        <th>Embed Text Direct Link</th>
        <td>
            <input type="text" name="directLinkText" value="<?php echo($options['directLinkText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Embed Text Embed Code</th>
        <td>
            <input type="text" name="embedCodeText" value="<?php echo($options['embedCodeText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Embed Code Copy text</th>
        <td>
            <input type="text" name="copyCodeText" value="<?php echo($options['copyCodeText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Embed Code Copied text</th>
        <td>
            <input type="text" name="copiedCodeText" value="<?php echo($options['copiedCodeText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Embed Code Copy title</th>
        <td>
            <input type="text" name="copyCodeTitle" value="<?php echo($options['copyCodeTitle']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Share On Tumblr</th>
        <td>
            <input type="text" name="tooltipTumblr" value="<?php echo($options['tooltipTumblr']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Share On Twitter</th>
        <td>
            <input type="text" name="tooltipTwitter" value="<?php echo($options['tooltipTwitter']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Share On Facebook</th>
        <td>
            <input type="text" name="tooltipFacebook" value="<?php echo($options['tooltipFacebook']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Share On Googleplus</th>
        <td>
            <input type="text" name="tooltipGoogleplus" value="<?php echo($options['tooltipGoogleplus']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Share On WhatsApp</th>
        <td>
            <input type="text" name="tooltipWhatsApp" value="<?php echo($options['tooltipWhatsApp']);?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Share On Reddit</th>
        <td>
            <input type="text" name="tooltipReddit" value="<?php echo($options['tooltipReddit']);?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Share On Digg</th>
        <td>
            <input type="text" name="tooltipDigg" value="<?php echo($options['tooltipDigg']);?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Share On LinkedIn</th>
        <td>
            <input type="text" name="tooltipLinkedIn" value="<?php echo($options['tooltipLinkedIn']);?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Share On Pinterest</th>
        <td>
            <input type="text" name="tooltipPinterest" value="<?php echo($options['tooltipPinterest']);?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Share</th>
        <td>
            <input type="text" name="tooltipShare" value="<?php echo($options['tooltipShare']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Share Close</th>
        <td>
            <input type="text" name="tooltipShareClose" value="<?php echo($options['tooltipShareClose']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Description Toggle</th>
        <td>
            <input type="text" name="tooltipInfo" value="<?php echo($options['tooltipInfo']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Info Close</th>
        <td>
            <input type="text" name="tooltipInfoClose" value="<?php echo($options['tooltipInfoClose']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Embed Toggle</th>
        <td>
            <input type="text" name="tooltipEmbed" value="<?php echo($options['tooltipEmbed']);?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Embed Close</th>
        <td>
            <input type="text" name="tooltipEmbedClose" value="<?php echo($options['tooltipEmbedClose']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Previous</th>
        <td>
            <input type="text" name="tooltipPrevious" value="<?php echo($options['tooltipPrevious']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Playback</th>
        <td>
            <input type="text" name="tooltipPlayback" value="<?php echo($options['tooltipPlayback']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Next</th>
        <td>
            <input type="text" name="tooltipNext" value="<?php echo($options['tooltipNext']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Rewind</th>
        <td>
            <input type="text" name="tooltipRewind" value="<?php echo($options['tooltipRewind']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip seek backward</th>
        <td>
            <input type="text" name="tooltipSeekBackward" value="<?php echo($options['tooltipSeekBackward']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip seek forward</th>
        <td>
            <input type="text" name="tooltipSeekForward" value="<?php echo($options['tooltipSeekForward']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Quality</th>
        <td>
            <input type="text" name="tooltipQuality" value="<?php echo($options['tooltipQuality']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Playback Rate</th>
        <td>
            <input type="text" name="tooltipPlaybackRate" value="<?php echo($options['tooltipPlaybackRate']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Audio Language</th>
        <td>
            <input type="text" name="tooltipAudioLanguage" value="<?php echo($options['tooltipAudioLanguage']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Picture in picture</th>
        <td>
            <input type="text" name="tooltipPip" value="<?php echo($options['tooltipPip']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Volume</th>
        <td>
            <input type="text" name="tooltipVolume" value="<?php echo($options['tooltipVolume']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Subtitles</th>
        <td>
            <input type="text" name="tooltipSubtitles" value="<?php echo($options['tooltipSubtitles']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Download</th>
        <td>
            <input type="text" name="tooltipDownload" value="<?php echo($options['tooltipDownload']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip settings menu</th>
        <td>
            <input type="text" name="tooltipSettings" value="<?php echo($options['tooltipSettings']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Fullscreen Enter</th>
        <td>
            <input type="text" name="tooltipFullscreenEnter" value="<?php echo($options['tooltipFullscreenEnter']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Fullscreen Exit</th>
        <td>
            <input type="text" name="tooltipFullscreenExit" value="<?php echo($options['tooltipFullscreenExit']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Toggle Playlist</th>
        <td>
            <input type="text" name="tooltipPlaylist" value="<?php echo($options['tooltipPlaylist']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Lightbox Close</th>
        <td>
            <input type="text" name="tooltipLightboxClose" value="<?php echo($options['tooltipLightboxClose']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Lightbox Previous</th>
        <td>
            <input type="text" name="tooltipLightboxPrevious" value="<?php echo($options['tooltipLightboxPrevious']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Lightbox Next</th>
        <td>
            <input type="text" name="tooltipLightboxNext" value="<?php echo($options['tooltipLightboxNext']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Playlist Shuffle</th>
        <td>
            <input type="text" name="tooltipPlaylistShuffle" value="<?php echo($options['tooltipPlaylistShuffle']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Playlist Loop</th>
        <td>
            <input type="text" name="tooltipPlaylistLoop" value="<?php echo($options['tooltipPlaylistLoop']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Playlist Previous</th>
        <td>
            <input type="text" name="tooltipPlaylistNext" value="<?php echo($options['tooltipPlaylistNext']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Playlist Next</th>
        <td>
            <input type="text" name="tooltipPlaylistPrevious" value="<?php echo($options['tooltipPlaylistPrevious']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Load More Button Text</th>
        <td>
            <input type="text" name="loadMoreBtnText" value="<?php echo($options['loadMoreBtnText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Select Playlist Text</th>
        <td>
            <input type="text" name="selectPlaylistText" value="<?php echo($options['selectPlaylistText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Up Next Thumbnail Text</th>
        <td>
            <input type="text" name="upNextText" value="<?php echo($options['upNextText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Tooltip Up Next Thumbnail Close</th>
        <td>
            <input type="text" name="tooltipUpNextClose" value="<?php echo($options['tooltipUpNextClose']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Subtitle Off Text</th>
        <td>
            <input type="text" name="subtitleOffText" value="<?php echo($options['subtitleOffText']); ?>"><br>
        </td>
    </tr>

    <tr valign="top">
        <th>Select Playlist Text</th>
        <td>
            <input type="text" name="adTitleText" value="<?php echo($options['adTitleText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Up Next Thumbnail Text</th>
        <td>
            <input type="text" name="adSkipWaitText" value="<?php echo($options['adSkipWaitText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Subtitle Off Text</th>
        <td>
            <input type="text" name="adSkipReadyText" value="<?php echo($options['adSkipReadyText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Password protected content title</th>
        <td>
            <input type="text" name="privateContentTitle" value="<?php echo($options['privateContentTitle']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Password protected confirm button text</th>
        <td>
            <input type="text" name="privateContentConfirm" value="<?php echo($options['privateContentConfirm']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Password protected content info</th>
        <td>
            <input type="text" name="privateContentInfo" value="<?php echo($options['privateContentInfo']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Password protected content wrong password error message</th>
        <td>
            <input type="text" name="privateContentPasswordError" value="<?php echo($options['privateContentPasswordError']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Custom context menu play text</th>
        <td>
            <input type="text" name="customContextMenuPlayText" value="<?php echo($options['customContextMenuPlayText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Custom context menu pause text</th>
        <td>
            <input type="text" name="customContextMenuPauseText" value="<?php echo($options['customContextMenuPauseText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Custom context menu mute text</th>
        <td>
            <input type="text" name="customContextMenuMuteText" value="<?php echo($options['customContextMenuMuteText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Custom context menu unmute text</th>
        <td>
            <input type="text" name="customContextMenuUnMuteText" value="<?php echo($options['customContextMenuUnMuteText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Custom context enter fullscreen text</th>
        <td>
            <input type="text" name="customContextMenuEnterFullscreenText" value="<?php echo($options['customContextMenuEnterFullscreenText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Custom context exit fullscreen text</th>
        <td>
            <input type="text" name="customContextMenuExitFullscreenText" value="<?php echo($options['customContextMenuExitFullscreenText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Search text (filter tracks)</th>
        <td>
            <input type="text" name="searchText" value="<?php echo($options['searchText']); ?>"><br>
        </td>
    </tr>
    <tr valign="top">
        <th>Search Nothing Found text</th>
        <td>
            <input type="text" name="nothingFoundText" value="<?php echo($options['nothingFoundText']); ?>"><br>
        </td>
    </tr>
    
</table>
