# CHANGELOG

## 1.2.1 (released 2015-05-07)

- Move from pem to cer

## 1.2.0 (released 2015-05-01)

- Better error messages when uploading (#66)
- Better error messages when curl errors (#68)
- Root cert is included to help with curl errors (#69)

## 1.1.0 (released 2014-10-23)

- Added composer support (#6)

## 1.0.0 (released 2014-09-26)

- This is the Vimeo library for version 3 of the Vimeo API.
